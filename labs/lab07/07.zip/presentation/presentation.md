---
## Front matter
lang: ru-RU
title: Операционные системы
subtitle: Анализ файловой структуры UNIX. Команды для работы с файлами и каталогами
author:
  - Татьяна Соколова
institute:
  - Российский университет дружбы народов, Москва, Россия
date: 11 марта 2025

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
---

## Formatting
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true

---

# Цели и задачи работы

## Цель лабораторной работы

Ознакомление с файловой системой Linux, её структурой, именами и содержанием каталогов. Приобретение практических навыков по применению команд для работы с файлами и каталогами, по управлению процессами, по проверке использования диска и обслуживанию файловой системы.

## Задачи лабораторной работы

1 Выполнить приимеры

2 Выполнить дествия по работе с каталогами и файлами

3 Выполнить действия с правами доступа

4 Получить дополнительные сведения при помощи справки по командам.

# Процесс выполнения лабораторной работы

## Выполнение примеров

![Выполнение примеров](image/01.png){ #fig:001 width=70% }

## Выполнение примеров

![Выполнение примеров](image/02.png){ #fig:002 width=70% }

## Выполнение примеров

![Выполнение примеров](image/03.png){ #fig:003 width=70% }

## Создание директорий и копирование файлов

![Работа с каталогами](image/04.png){ #fig:004 width=70% }

## Работа с командой chmod

![Настройка прав доступа](image/05.png){ #fig:005 width=70% }

## Файл /etc/passwd

![Файл /etc/passwd](image/06.png){ #fig:006 width=70% }

## Работа с файлами и правами доступа

![Работа с файлами и правами доступа](image/07.png){ #fig:007 width=70% }

## Справка по командам

![Команда mount](image/08.png){ #fig:008 width=70% }

## Справка по командам

![Команда fsck](image/09.png){ #fig:009 width=70% }

## Справка по командам

![Команда mkfs](image/10.png){ #fig:010 width=70% }

## Справка по командам

![Команда kill](image/11.png){ #fig:011 width=70% }

# Выводы по проделанной работе

## Вывод

В ходе данной работы мы ознакомились с файловой системой Linux, её структурой, именами и содержанием каталогов. Научились совершать базовые операции с файлами, управлять правами их доступа для пользователя и групп. Ознакомились с Анализом файловой системы. А также получили базовые навыки по проверке использования диска и обслуживанию файловой системы.

